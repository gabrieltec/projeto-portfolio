package com.empresa.portfolio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PortfolioProjetoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PortfolioProjetoApplication.class, args);
	}

}
